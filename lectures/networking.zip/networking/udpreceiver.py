import socket
from datetime import datetime
HOST = "127.0.0.1"
PORT = 12345
with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as rs:
    rs.bind((HOST, PORT))
    print("Listening...")
    data, addr = rs.recvfrom(1024)
    print(f'Received {data} from {addr} at {datetime.now()}')
    rs.sendto(data, addr)
