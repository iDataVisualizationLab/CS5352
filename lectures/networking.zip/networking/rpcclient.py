from xmlrpc.client import ServerProxy

with ServerProxy('http://127.0.0.1:12345') as sp:
    print(sp.system.listMethods())
    print(sp.pow(2, 3))
    print(sp.multiply(2, 3))
    print(sp.add(2, 3))
