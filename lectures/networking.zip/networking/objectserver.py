import Pyro4

HOST = "127.0.0.1"
PORT = 12345
NS_HOST = "127.0.0.1"
NS_PORT = 23456


@Pyro4.expose
class MyCls:
    def greet(self, name):
        return f'Hello, {name}'


daemon = Pyro4.Daemon(HOST, PORT)
uri = daemon.register(MyCls)
# Need to run the naming server before this (pyro4-ns -h for options)
ns = Pyro4.locateNS(NS_HOST, NS_PORT)
ns.register('myCls', uri)

print(f'Serving myCls at {NS_HOST}:{NS_PORT} name server')
daemon.requestLoop()
