import socket
from datetime import datetime
HOST = "127.0.0.1"
PORT = 12345

with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as ss:
    ss.sendto(b'Hello, world!', (HOST, PORT))
    print('Sent, and now listening...')
    data, addr = ss.recvfrom(1024)
    print(f'Received {data} from {addr} at {datetime.now()}')
