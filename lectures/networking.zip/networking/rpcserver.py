from xmlrpc.server import SimpleXMLRPCServer
from xmlrpc.server import SimpleXMLRPCRequestHandler

HOST = "127.0.0.1"
PORT = 12345

with SimpleXMLRPCServer((HOST, PORT), SimpleXMLRPCRequestHandler) as rpcs:
    rpcs.register_function(pow)


    def mul(x, y):
        return x * y

    rpcs.register_function(mul, 'multiply')

    class MyMath:
        def add(self, x, y):
            return x+y

    rpcs.register_instance(MyMath())
    rpcs.register_introspection_functions()
    print("Serving ...")
    rpcs.serve_forever()
