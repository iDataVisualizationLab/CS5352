import Pyro4

with Pyro4.Proxy('PYRONAME:myCls@127.0.0.1:23456') as myCls:
    print(myCls.greet('Mr. A'))
