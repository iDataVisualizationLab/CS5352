import os
import PySimpleGUI as gui
import psutil as ps
import matplotlib.pyplot as matplt
import pandas as pd
import numpy as num
from PIL import Image

gui.theme('BluePurple')


file_selection = [[gui.Text('Select the files for Knuth Morris Pratt and Boyer Moore Algorithm')],

          [gui.Text(size=(10,0), key='-OUTPUT-')],
          [gui.Text('Knuth Morris Pratt Algorithm file')],
          [gui.Input(), gui.FileBrowse()],
          [gui.Text('Boyer Moore Algorithm file')],
          [gui.Input(), gui.FileBrowse()],
         [gui.Button('Start Analysis'), gui.Button('Exit Analysis')], ]


window = gui.Window('Comparision of Algorithms for String/Pattern Matching', file_selection)

Knuthmorrispratt = []
boyermoore = []
kmp_bmoore = []


print("********This is the sequential execution of algorithms********")

def calculation_analysis(alg_name, i):
    os.system(alg_name)

    process_id = os.getpid()

    py_process = ps.Process(process_id)

    memory_info = py_process.memory_full_info()

    print("This the analysis for the " + alg_name)

    print("The process id is : " + str(process_id))

    print("Percentage of CPU Used is : " + str(py_process.cpu_percent()))

    print('Percentage of Memory Used is : ' + str(py_process.memory_percent()))

    print('The amount of disk usage is : ' + str(ps.disk_usage('/').used))

    used_memory = py_process.memory_info()[0] / 2. ** 30
    print('The amount of memory usage is : ', used_memory, "GB")

    virtual_memory_used = py_process.memory_info()[1] / 2. ** 30
    print('The total virtual memory(vms) used by the process is :', virtual_memory_used, "GB")

    print('The number of page faults are : ' + str(memory_info[2]))

    print("\n")

    data = []
    data.append(py_process.cpu_percent())
    data.append(py_process.memory_percent())
    data.append(ps.disk_usage('/').used)
    data.append(used_memory)
    data.append(virtual_memory_used)
    data.append(memory_info[2])

    if (i == 1):
        Knuthmorrispratt = data
        return Knuthmorrispratt
    else:
        boyermoore = data
        return boyermoore

def parallel_calculation_analysis(alg_name1, alg_name2):

    cmd_line = 'python ' + alg_name1
    cmd_line += ' && python ' + alg_name2
    os.system(cmd_line)

    process_id = os.getpid()

    py_process = ps.Process(process_id)

    memory_info = py_process.memory_full_info()

    print("This the analysis for the Knuth Morris Pratt and Boyer-Moore Algorithm for Pattern Matching")

    print("The process id is : " + str(process_id))

    print("Percentage of CPU Used is : " + str(py_process.cpu_percent()))

    print('Percentage of Memory Used is : ' + str(py_process.memory_percent()))

    print('The amount of disk usage is : ' + str(ps.disk_usage('/').used))

    used_memory = py_process.memory_info()[0] / 2. ** 30
    print('The amount of memory usage is : ', used_memory, "GB")

    virtual_memory_used = py_process.memory_info()[1] / 2. ** 30
    print('The total virtual memory(vms) used by the process is :', virtual_memory_used, "GB")

    print('The number of page faults are : ' + str(memory_info[2]))

    print("\n")

    data = []
    data.append(py_process.cpu_percent())
    data.append(py_process.memory_percent())
    data.append(ps.disk_usage('/').used)
    data.append(used_memory)
    data.append(virtual_memory_used)
    data.append(memory_info[2])

    kmp_bmoore = data
    return kmp_bmoore

def TableCreation(data1, data2, data3):
    new_data1 = []
    new_data2 = []
    new_data3 = []

    for d in data1:
        new_data1.append(str(d))

    for d in data2:
        new_data2.append(str(d))

    for d in data3:
        new_data3.append(str(d))

    df = pd.DataFrame({'KMP': new_data1, 'Boyer-Moore': new_data2, 'KMP & Boyer-Moore Parallel': new_data3})

    print("Tabular Comparision of algorithm performance:")

    print('Index 0 : CPU usage', 'Index 1 : Memory usage', 'Index 2 : Hard drive usage', 'Index 3 : RSS',
          'Index 4 : VMS', 'Index 5 : Number of page faults')

    print(df)

def PlotAnalysis():
    algos = 'KMP', 'Boyer-Moore', 'KMP & Boyer-Moore parallel'

    plot_title = ''
    i = 0

    graph_iterator = 1

    for array_index in range(6):

        if array_index == 0:
            plot_title = 'CPU Usage'
        elif array_index == 1:
            plot_title = 'Memory Usge'
        elif array_index == 2:
            plot_title = 'Hard Drive Usage'
        elif array_index == 3:
            plot_title = 'RSS'
        elif array_index == 4:
            plot_title = 'VMS'
        else:
            plot_title = 'Number of page faults'

        bar_values = []

        bar_values.append(Knuthmorrispratt[array_index])
        bar_values.append(boyermoore[array_index])
        bar_values.append(kmp_bmoore[array_index])

        matplt.subplot(3, 2, graph_iterator)
        graph_iterator += 1

        colors = ['gold', 'yellowgreen', 'lightcoral']
        matplt.bar(algos, bar_values, align='center', alpha=0.5, color=colors)
        matplt.grid(color='#95a5a6', linestyle='--', linewidth=2, axis='y', alpha=0.7)
        matplt.xticks(algos)
        matplt.ylabel(plot_title)

    return matplt.show()


while True:
    event, file_name = window.read()
    if event in (None, 'Exit Analysis'):
        break


    print("\n")
    print("This is the output for Knuth Morris Pratt Algorithm for Pattern searching")
    Knuthmorrispratt = calculation_analysis(file_name[0], 1)

    print("\n")
    print("This is the output for Boyer-Moore Algorithm for Pattern searching")
    boyermoore = calculation_analysis(file_name[1], 2)

    print("********This is parallel execution of Algorithms********")
    kmp_bmoore = parallel_calculation_analysis(file_name[0], file_name[1])

    TableCreation(Knuthmorrispratt, boyermoore, kmp_bmoore)

    im = Image.open(r"Power Consumption Statistics.png")

    im.show()

    window.close()

    PlotAnalysis()


