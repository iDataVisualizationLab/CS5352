statement = "This is Dhruv Chetan Mehta"
pattern = "Mehta"