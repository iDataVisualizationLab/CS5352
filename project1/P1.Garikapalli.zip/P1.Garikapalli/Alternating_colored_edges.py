# Python implementation of the approach 
  
graph = [[[0, 0] for i in range(18)] for j in range(18)] 
  
# Initializing dp of size = 
# (2^18)*18*2. 
dp = [[[0, 0] for i in range(18)] for j in range(1 << 15)] 
  
# Recursive Function to calculate 
# Minimum Cost with alternate 
# colour edges 
def minCost(n: int, m: int, mask:  
            int, prev: int, col: int) -> int: 
    global dp 
  
    # Base case 
    if mask == ((1 << n) - 1): 
        return 0
  
    # If already calculated 
    if dp[mask][prev][col == 1] != 0: 
        return dp[mask][prev][col == 1] 
  
    ans = int(1e9) 
  
    for i in range(n): 
        for j in range(2): 
  
            # Masking previous edges 
            # as explained in above formula. 
            if graph[prev][i][j] and not (mask & (1 << i)) and (j != col):
                z = graph[prev][i][j] + minCost(n, 
                        m, mask | (1 << i), i, j) 
                ans = min(z, ans) 
  
    dp[mask][prev][col == 1] = ans 
    return dp[mask][prev][col == 1] 
  
# Function to Adjacency 
# List Representation 
# of a Graph 
def makeGraph(vp: list, m: int): 
    global graph 
    for i in range(m): 
        a = vp[i][0][0] - 1
        b = vp[i][0][1] - 1
        cost = vp[i][1][0] 
        color = vp[i][1][1] 
        graph[a][b][color == 'W'] = cost 
        graph[b][a][color == 'W'] = cost 
  
# Function to getCost 
# for the Minimum Spanning 
# Tree Formed 
# Alternating colored edges

def getCost(n: int, m: int) -> int: 
  
    # Assigning maximum 
    # possible value. 
    ans = int(1e9) 
    for i in range(n): 
        ans = min(ans, minCost(n, m, 1 << i, i, 2)) 
  
    if ans != int(1e9): 
        return ans 
    else: 
        return -1
  
# Driver Code 
if __name__ == "__main__": 
  
    n = 3
    m = 4
    vp = [[[1, 2], [2, 'B']], 
        [[1, 2], [3, 'W']], 
        [[2, 3], [4, 'W']], 
        [[2, 3], [5, 'B']]] 
    makeGraph(vp, m) 
    print(getCost(n, m)) 