Read Me
Project 1: Retrieving, comparing, and presenting process profiling data

Step - 1:- Unzip the P1.Garikapalli.zip folder

Step - 2:- Open Jupyter Notebook

Step - 3:- Open Code.ipynb in the unzipped folder in Jupyter Notebook

Step - 4:- Run the code block by block for final output

Note - 
	After running the fourth block of code, the program will output the User-Level Information and System-Level 	Information of the Alternating Colored Edges algorithm
	After running the fifth block of code, the program will output the User-Level Information and System-Level 			Information of the Reverse Delete Algorithm
	After running the sixth block of code, the program will output the User-Level Information and System-Level 			Information of the Alternating Colored Edges algorithm and Reverse Delete Algorithm running concurrently
	After running the seventh block of code, the program will output the bar graph of comparison to execution times in 	the above three cases.
