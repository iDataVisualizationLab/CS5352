from BucketSort import bucket_sort as Bucket
from RadixSort import radix_sort as Radix
from multiprocessing import Process, Manager

class Sorting:

    @staticmethod
    def bucket_sort(end):
        Bucket(end)

    @staticmethod
    def radix_sort(end):
        return Radix(end)

    @staticmethod
    def both_programs_once(end):
        P1 = Process(target=Radix, args=(end, ))
        P2 = Process(target=Bucket, args=(end, ))
        P1.start()
        P2.start()
        P1.join()
        P2.join()


if __name__ == '__main__':
    sort = Sorting()
    option=input('Enter r for radix-sort or Enter b for bucket-sort or Enter m for both-sorts: ')
    end = input('Enter positive elements to sort with space seperated: ').split()
    end = [int(x) for x in end]
    if option == 'r':
        sort.radix_sort(end)
    elif option == 'b':
        sort.bucket_sort(end)
    elif option == 'm':
        sort.both_programs_once(end)

