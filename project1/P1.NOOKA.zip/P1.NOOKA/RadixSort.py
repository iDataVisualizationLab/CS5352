import os
import inline as inline
import matplotlib
import psutil
import math
import time
from matplotlib import pyplot as plt
from psutil._common import bytes2human
import timeit
import matplotlib.pyplot as plt; plt.rcdefaults()
import numpy as np
import matplotlib.pyplot as plt


pid_Radix = os.getpid()
py_Radix = psutil.Process()



# Python program for implementation of Radix Sort
def radix_sort(nums):
    startTime = time.time()
    RADIX = 10
    placement = 1
    max_digit = max(nums)

    while placement < max_digit:
      buckets = [list() for _ in range( RADIX )]
      for i in nums:
        tmp = int((i / placement) % RADIX)
        buckets[tmp].append(i)
      a = 0
      for b in range( RADIX ):
        buck = buckets[b]
        for i in buck:
          nums[a] = i
          a += 1
      placement *= RADIX
    print('Radix Sorted list: ', end='')
    print(nums)
    endTime = time.time()
    total_time_taken = endTime-startTime
    return sorting_data(total_time_taken,pid_Radix, py_Radix)




def sorting_data(total_time_taken,pid, py):
    hardisk=psutil.disk_usage('/').percent
    cpu_percentage = psutil.cpu_times_percent(interval=0.4, percpu=False)._asdict()
#print(cpu_percentage)
    memory_percentage = py.memory_percent()

    mem = py.memory_info()._asdict()

    values = []
    values1 = []
    values.append(mem['rss'])
    values.append(mem['vms'])
    values_in_m = []
    for i in values:
       values_in_m.append(bytes2human(i))

    values1.append(cpu_percentage)
    values1.append(memory_percentage)

    print(f"Radix Sorted Data::: RSS: {mem['rss']}, Virtual Memory: {mem['vms']}, Page Faults:{mem['num_page_faults']}, "
      f"CPU %: {cpu_percentage}, Memory %: {memory_percentage},Total Time Taken %: {total_time_taken} Seconds,Hard disk usage %:{hardisk}")


    # code added for display  start
    cpu_usage_values = [cpu_percentage['user'], cpu_percentage['system'] + cpu_percentage['interrupt'] + cpu_percentage['dpc'],
                        cpu_percentage['idle']]
    activities = ['user', 'system', 'idle']
    explode = (0.1, 0, 0.2)
    colors = ['red', 'grey', 'yellow']
    plt.subplot(2, 2, 1)
    plt.pie(cpu_usage_values, labels=activities, startangle=140, autopct='%2.1f%%', colors=colors, explode=explode)
    plt.title('CPU Utilisation for Radix Sort')

    plt.subplot(2, 2, 2)
    objects = ('RSS', 'VMS')
    y_pos = np.arange(len(objects))
    performance = [mem['rss'], mem['vms']]
    plt.bar(y_pos, performance, align='center', alpha=0.5)
    plt.xticks(y_pos, objects)
    plt.ylabel('  Usage')
    plt.title('         Residual & Virtual Memory')

    plt.subplot(2, 2, 3)
    objects = ('Mem Usage', 'HardDisk Usage')
    y_pos = np.arange(len(objects))
    performance = [memory_percentage, hardisk]
    plt.bar(y_pos, performance, align='center', alpha=0.5)
    plt.xticks(y_pos, objects)
    plt.ylabel('% of memory Usage')
    plt.title('Memory Usage of Radix Sort')

    plt.show()
    # code added for display  end
