import os
import inline as inline
import matplotlib
import psutil
import math
import time
from matplotlib import pyplot as plt
from psutil._common import bytes2human
import timeit
import matplotlib.pyplot as plt; plt.rcdefaults()
import numpy as np
import matplotlib.pyplot as plt

pid_Bucket = os.getpid()
py_Bucket = psutil.Process()



# Python3 program to sort an array
# using bucket sort

def bucket_sort(alist):
     startTime = time.time()
     largest = max(alist)
     length = len(alist)
     size = largest / length

     buckets = [[] for _ in range(length)]
     for i in range(length):
          j = int(alist[i] / size)
          if j != length:
               buckets[j].append(alist[i])
          else:
               buckets[length - 1].append(alist[i])

     for i in range(length):
          insertion_sort(buckets[i])

     result = []
     for i in range(length):
          result = result + buckets[i]
     print('Bucket Sorted list: ', end='')
     print(result)
     endTime = time.time()
     total_time_taken = endTime-startTime
     return sorting_data(total_time_taken,pid_Bucket, py_Bucket)


def insertion_sort(alist):
     for i in range(1, len(alist)):
          temp = alist[i]
          j = i - 1
          while (j >= 0 and temp < alist[j]):
              alist[j + 1] = alist[j]
              j = j - 1
          alist[j + 1] = temp





def sorting_data(total_time_taken,pid, py):
    hardisk=psutil.disk_usage('/').percent
    cpu_percentage = psutil.cpu_times_percent(interval=0.4, percpu=False)._asdict()
#print(cpu_percentage)
    memory_percentage = py.memory_percent()

    mem = py.memory_info()._asdict()

    values = []
    values1 = []
    values.append(mem['rss'])
    values.append(mem['vms'])
    values_in_m = []
    for i in values:
       values_in_m.append(bytes2human(i))

    values1.append(cpu_percentage)
    values1.append(memory_percentage)

    print(f"Bucket Sorted Data::: RSS: {mem['rss']}, Virtual Memory: {mem['vms']}, Page Faults:{mem['num_page_faults']}, "
      f"CPU %: {cpu_percentage}, Memory %: {memory_percentage},Total Time Taken %: {total_time_taken} Seconds,Hard disk usage %:{hardisk}\n")


    # code added for display  start
    cpu_usage_values = [cpu_percentage['user'], cpu_percentage['system'] + cpu_percentage['interrupt'] + cpu_percentage['dpc'],
                        cpu_percentage['idle']]
    activities = ['user', 'system', 'idle']
    explode = (0.1, 0, 0.2)
    colors = ['gold', 'yellowgreen', 'lightcoral']
    plt.subplot(2, 2, 1)
    plt.pie(cpu_usage_values, labels=activities, startangle=140, autopct='%2.1f%%', colors=colors, explode=explode)
    plt.title('CPU Utilisation for Bucket Sort')

    plt.subplot(2, 2, 2)
    objects = ('RSS', 'VMS')
    y_pos = np.arange(len(objects))
    performance = [mem['rss'], mem['vms']]
    plt.bar(y_pos, performance, align='center', alpha=0.5)
    plt.xticks(y_pos, objects)
    plt.ylabel('  Usage')
    plt.title('         Residual & Virtual Memory')

    plt.subplot(2, 2, 3)
    objects = ('Mem Usage', 'HardDisk Usage')
    y_pos = np.arange(len(objects))
    performance = [memory_percentage, hardisk]
    plt.bar(y_pos, performance, align='center', alpha=0.5)
    plt.xticks(y_pos, objects)
    plt.ylabel('% of memory Usage')
    plt.title('Memory Usage of Bucket Sort')

    plt.show()
    # code added for display  end
