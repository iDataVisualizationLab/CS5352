import os
import psutil
import dbscan
import kmeans


def systemDetails():
    Data = []
    pid = os.getpid()
    py = psutil.Process(pid)

    cpuTimeUsage = psutil.cpu_times_percent(interval=1, percpu=False)
    print("CPU Usage: ", cpuTimeUsage, "\n")  # 1
    Data.append(cpuTimeUsage)

    memory_utilization = py.memory_percent()
    print("Memory Usage: ", memory_utilization, " \n")  # 2
    Data.append(memory_utilization)

    hardDiskUtilization = psutil.disk_usage('/')
    print("Hard Drive Usage:")
    print("Total: ", hardDiskUtilization.total / (2 ** 30), " GB, Used: ", hardDiskUtilization.used / (2 ** 30), " GB Free: ",
          hardDiskUtilization.free / (2 ** 30),
          " GB \n")  # 3
    Data.append(hardDiskUtilization)

    memory_info = py.memory_info()
    rss = memory_info[0] / 2. ** 30
    print("RSS (Resident set size): ", rss, " GB \n")  # 4
    Data.append(rss)

    vms = memory_info[1] / 2. ** 30
    print("VMS (Virtual memory size): ", vms, " GB \n")  # 5
    Data.append(vms)

    pf = memory_info[2]
    print("No. of Page faults: ", pf, "\n\n\n")  # 6
    Data.append(pf)


filename1 = dbscan
filename2 = kmeans

os.system('python ' + str(filename1))
systemDetails()

os.system('python ' + str(filename2))
systemDetails()

os.system('python ' + str(filename1) + ' && python ' + str(filename2))
systemDetails()
