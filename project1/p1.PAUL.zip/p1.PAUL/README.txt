Thankyou for taking the time to review my project
The project has one main project file and two algortithm files, which are:
1)mergesort.py
2)timsort.py

Steps to run the code comparator
1)open your terminal
2)type 'python project1.py' and press Enter
3)Input the two algorithms that you want to compare
4)It will finish processing and display the results as bar graphs. 
	NOTE: Maximize the results window to view all the details clearly.
There are two images one with the required 500px X 500 px and the second one is the original image