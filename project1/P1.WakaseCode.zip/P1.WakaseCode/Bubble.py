from datetime import datetime
start_time = datetime.now()
def bubbleSort(data): 
    n = len(data)
    for i in range(n): 
        swapped = False
        for j in range(0, n-i-1): 
            if data[j] > data[j+1] : 
                data[j], data[j+1] = data[j+1], data[j] 
                swapped = True    
        if swapped == False: 
            break
def printList(data): 
    for i in range(len(data)):         
        print(int(data[i]),end=" ")
    #print()
if __name__ == '__main__':
    data = [64, 34, 25, 12, 22, 11, 90, 0, 1, 9, 22, 44, 55, 63, 85, 2, 3, 0,10, 2,100,200,7,0]
    #n = len(data)
    printList(data)
    print ("\nSorted array :")
    bubbleSort(data)
    #cProfile.run('bubbleSort(data)')
    for i in range(len(data)): 
      print ("%d" %data[i],end=" ")
    #print ("",end=" ") 

    end_time = datetime.now()
    print('\n 1.running time for Bubble sort is: {}'.format(end_time - start_time))



