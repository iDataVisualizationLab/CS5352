import multiprocessing
import os
import psutil
import time
from datetime import datetime
start_time = datetime.now()
def bubbleSort(data): 
    n = len(data)
    for i in range(n): 
        swapped = False
        for j in range(0, n-i-1): 
            if data[j] > data[j+1] : 
                data[j], data[j+1] = data[j+1], data[j] 
                swapped = True    
        if swapped == False: 
            break
    for i in range(len(data)): 
        print ("%d" %data[i],end=" ")
    end_time = datetime.now()
    print('\n 1.running time for Bubble sort is: {}'.format(end_time - start_time))

def insertionSort(data):
      for i in range(1, len(data)): 
        count =0
        Temp = data[i] 
        j = i-1
        while j >= 0 and Temp < data[j] : 
                data[j + 1] = data[j] 
                j -= 1
        data[j + 1] = Temp
      for i in range(len(data)): 
         print ("%d" %data[i],end=" ")
      end_time = datetime.now()
      print('\n 1.running time for Insertion sort is: {}'.format(end_time - start_time))


def details():
    Values=[]
    pid = os.getpid()
    py = psutil.Process(pid)
    print("PID",pid)
    print("\n1.CPU usage is(%):", py.cpu_percent())
    cpuTimeUsage = psutil.cpu_times_percent(interval=1, percpu=False)
    print("CPU Usage: ", cpuTimeUsage) 
    Values.append(cpuTimeUsage)

    memory_utilization = py.memory_percent()
    print("\nMemory Usage: ", memory_utilization,)
    Values.append(memory_utilization)

    hardDiskUtilization = psutil.disk_usage('/')
    print("Hard Drive Usage:")
    print("\ntotal: ", hardDiskUtilization.total / (2 ** 30), " GB, \nused: ", hardDiskUtilization.used / (2 ** 30),
              " GB \nFree: ",
              hardDiskUtilization.free / (2 ** 30),
              " GB")


    Values.append(hardDiskUtilization)
    print("\nmemory Info\n", py.memory_info())
    memory_info = py.memory_info()
    rss = memory_info[0] / 2. ** 30
    print("\nRSS (Resident set size): ", rss, " GB")
    Values.append(rss)

    vms = memory_info[1] / 2. ** 30
    print("\nVMS (Virtual memory size): ", vms, " GB")
    Values.append(vms)

    pagefault = memory_info[2]
    print("\nNo. of Page faults: ", pagefault) 
    Values.append(pagefault)

if __name__ == '__main__':
    data = [64, 34, 25, 12, 22, 11, 90, 0, 1, 9, 22, 44, 55, 63, 85, 2, 3, 0,10, 2,100,200,7,0]

    p1 = multiprocessing.Process(name='p1', target=bubbleSort(data))   ##Enable when Only bubble or Both program
    #p2 = multiprocessing.Process(name='p2', target=insertionSort(data)) ##Enable when only Insertion or Both program.

    p = multiprocessing.Process(name='p', target=details())     
    p1.start()
    #p2.start()
    p.start()
    print("Done")
