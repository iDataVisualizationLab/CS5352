from __future__ import print_function
from datetime import datetime
import psutil
import datetime
import numpy as np
import warnings
warnings.filterwarnings('ignore')
import glob
import pandas as pd
import os
import multiprocessing as mp
import json
import os.path
import re
import pandas.core.algorithms as algos
from pandas import Series
import scipy.stats.stats as stats
import matplotlib.pyplot as plt
import seaborn as sns
import collections
import sys
import subprocess

#print("CPU Count",psutil.cpu_count) 
#print("\nCPU usage perinterval is:",psutil.cpu_percent(interval=1, percpu=True))

print("CPU Percentage per interval",psutil.cpu_percent(interval=1, percpu=True))
pid = os.getpid()
py = psutil.Process(pid)
print("PID",pid)
print("\nMemory Info",py.memory_info())
print("\nDisk Uses:",psutil.disk_usage('/'))

print("Is CPU is running:",py.is_running())
print("\n1.CPU usage is:",py.cpu_percent())
#print("\n3.Memory usage:",py.memory_full_info())
p=psutil.disk_usage('/')
print('\n2.Disk Use in total:',p[1])


memoryUse = py.memory_info()[0]/2.**30 
print('\n3.memory(rss):', memoryUse, "GB")
memoryUse = py.memory_info()[1]/2.**30 
print('\n4.memory(vms):', memoryUse, "GB")
memoryUseInPer=py.memory_percent() #Compare process memory to total physical system memory
print('\nmemory Uses in Percenge:', memoryUseInPer, "%")
memoryUse = py.memory_info()[2]
print('\n5.Number of Page Fault',memoryUse)

print('\nvirtual_memory in % is:',psutil.virtual_memory())


