from datetime import datetime
start_time = datetime.now()
def insertionSort(data):                                     #Perform Insertion sort funtion
      for i in range(1, len(data)): 
        count =0
        Temp = data[i] 
        j = i-1
        while j >= 0 and Temp < data[j] : 
                data[j + 1] = data[j] 
                j -= 1
        data[j + 1] = Temp 
def printList(data): 
    for i in range(len(data)):         
        print(int(data[i]),end=" ")
    print()
if __name__ == '__main__':
    data = [64, 34, 25, 12, 22, 11, 90, 0, 1, 9, 22, 44, 55, 63, 85, 2, 3, 0,10, 2,100,200,7,0]
    printList(data)
    insertionSort(data)                         #call Insertion sort funtion
    print("Sorted Array is:")
    for i in range(len(data)): 
      print ("%d" %data[i],end=" ") 
    end_time = datetime.now()
    print('\n 1.running time for Insertion Sort is: {}'.format(end_time - start_time))
