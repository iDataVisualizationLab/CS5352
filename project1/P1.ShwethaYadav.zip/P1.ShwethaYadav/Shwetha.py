import os
import psutil
import DecisionTree
import SVM


def systemDetails():
    Data = []
    pid = os.getpid()
    py = psutil.Process(pid)

    CPU_Usage = psutil.cpu_times_percent(interval=1, percpu=False)
    print("CPU Usage: ", CPU_Usage, "\n")  # 1
    Data.append(CPU_Usage)

    Memory_Usage = py.memory_percent()
    print("Memory Usage: ", Memory_Usage, " \n")  # 2
    Data.append(Memory_Usage)

    HardDisk = psutil.disk_usage('/')
    print("Hard Drive Usage:")
    print("Total: ", HardDisk.total / (2 ** 30), " GB, Used: ", HardDisk.used / (2 ** 30), " GB Free: ",
          HardDisk.free / (2 ** 30),
          " GB \n")  # 3
    Data.append(HardDisk)

    memory_info = py.memory_info()
    rss = memory_info[0] / 2. ** 30
    print("Resident set size(RSS): ", rss, " GB \n")  # 4
    Data.append(rss)

    vms = memory_info[1] / 2. ** 30
    print("Virtual memory size (VMS): ", vms, " GB \n")  # 5
    Data.append(vms)

    pf = memory_info[2]
    print("Number of Page faults: ", pf, "\n\n\n")  # 6
    Data.append(pf)


filename1 = DecisionTree
filename2 = SVM

os.system('python ' + str(filename1))
systemDetails()

os.system('python ' + str(filename2))
systemDetails()

os.system('python ' + str(filename1) + ' && python ' + str(filename2))
systemDetails()
