import numpy as np
import pandas as pd
from matplotlib import pyplot as plt
from sklearn.tree import DecisionTreeClassifier
from sklearn.model_selection import train_test_split
from sklearn import metrics

col_names = ['pregnant', 'glucose', 'bp', 'skin', 'insulin', 'bmi', 'pedigree', 'age', 'label']

data_set = pd.read_csv("diabetes.csv", header=None, names = col_names)
data_set.drop(index = 0, axis = 0, inplace = True)
feature_names = ['pregnant', 'insulin', 'bmi', 'age','glucose','bp','pedigree']
target_names = ['label']
X = data_set[feature_names]
y = data_set[target_names]

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=1)

# Create Decision Tree classifer object
clf = DecisionTreeClassifier(criterion="entropy", max_depth=3)

# Train Decision Tree Classifer
clf = clf.fit(X_train,y_train)

#Predict the response for test dataset
y_pred1 = clf.predict(X_test)

print(y_pred1)

print(clf.predict([[7, 175, 34.2, 16, 12, 832, 0.26]]))