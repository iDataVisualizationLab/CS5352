import random
import psutil
import os
import threading
import time

class SSSort:
    arr = []  # class var access by className.arr

    def __init__(self, n):
        self.n = n

    def generate1000_5digit_RandomNum(self):
        for i in range(self.n):
            num = random.randint(10000, 99999)
            SSSort.arr.append(num)

        for j in range(self.n):
            print("random {0}".format(SSSort.arr[j]))

    def cpu_util_info(self):#make sure different than posted
        k= self.n
        arr2 = SSSort.arr[:]
        def find_the_min_element(k, i, arr2):
           min = i
           for j in range(i+1, k):
              if (arr2[j] < arr2[min]):
                 min = j
           return min

        def selectionSort(k, arr2):
            for i in range(self.n):
                min = find_the_min_element(k, i, arr2)
                # swap min and ith element of array
                temp = arr2[min]
                arr2[min]= arr2[i]
                arr2[i] =temp

            for i in enumerate(arr2):
                print(i)


        pid = os.getpid()  # current process
        print("start thread")
        psutil.Process(pid).cpu_percent(interval=0)
        th = threading.Thread(target=selectionSort, args=(k, arr2))
        th.start()
        util_each_sec =0
        while th.is_alive():
            util_each_sec= util_each_sec+psutil.Process(pid).cpu_percent(interval=1)
        print("Total utilization = {0}".format(util_each_sec))
        print("all done")



    def main(self):
        self.generate1000_5digit_RandomNum()
        self.cpu_util_info()
        print("memory usage= ", psutil.Process(os.getpid()).memory_info()[0])
        print("disk usage= ", psutil.disk_usage('/'))
        print("virtual mem= ", psutil.virtual_memory().available)
        print("rss= ", psutil.Process(os.getpid()).memory_info().rss)


if __name__ == "__main__":
    start_time = time.time()
    objSSSort = SSSort(1000)
    objSSSort.main()
    print("--- %s seconds ---" % (time.time() - start_time))

