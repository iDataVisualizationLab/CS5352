
import random
import psutil
import os
import threading

class SSSort:
    arr = []  # class var access by className.arr

    def __init__(self, n):
        self.n = n

    def generate1000_5digit_RandomNum(self):
        for i in range(self.n):
            num = random.randint(10000, 99999)
            SSSort.arr.append(num)

        for j in range(self.n):
            print("random {0}".format(SSSort.arr[j]))

    def cpu_util_info(self):  # make sure different than posted
        k = self.n
        arr2 = SSSort.arr[:]

        def find_the_min_element(k, i, arr2):
           min = i
           for j in range(i + 1, k):
               if (arr2[j] < arr2[min]):
                   min = j
           return min

        def BubbleSort(k, arr2):
            for i in arr2:
                for j in range(len(arr2) - 1):
                    if (arr2[j] > arr2[j + 1]):
                         temp = arr2[j]
                         arr2[j] = arr2[j + 1]
                         arr2[j + 1] = temp

            for i in enumerate(arr2):
                print(i, threading.currentThread().getName())

        def find_the_min_element(k, i, arr2):
           min = i
           for j in range(i+1, k):
              if (arr2[j] < arr2[min]):
                 min = j
           return min

        def selectionSort(k, arr2):
            for i in range(self.n):
                min = find_the_min_element(k, i, arr2)
                # swap min and ith element of array
                temp = arr2[min]
                arr2[min]= arr2[i]
                arr2[i] =temp

            for i in enumerate(arr2):
                print(i, threading.currentThread().getName())


        pid = os.getpid()  # current process
        print("start thread")
        psutil.Process(pid).cpu_percent(interval=0)
        th1 = threading.Thread(name='t1', target=BubbleSort, args=(k, arr2))
        th2 = threading.Thread(name='t2', target=selectionSort, args=(k, arr2))
        th1.start()
        th2.start()
        cpu_util_per =0
        while th1.is_alive() or th2.is_alive():
            cpu_util_per = psutil.Process(pid).cpu_percent(interval=1) + cpu_util_per
        print ("Total cpu_percentage = {0}".format(cpu_util_per))
        print("all done")



    def main(self):
         self.generate1000_5digit_RandomNum()
         self.cpu_util_info()
         print("memory usage= ", psutil.Process(os.getpid()).memory_info()[0])
         print("disk usage= ", psutil.disk_usage('/'))
         print("virtual mem= ", psutil.virtual_memory().available)
         print("rss= ", psutil.Process(os.getpid()).memory_info().rss)

if __name__ == "__main__":
    objSSSort = SSSort(1200)
    objSSSort.main()





















